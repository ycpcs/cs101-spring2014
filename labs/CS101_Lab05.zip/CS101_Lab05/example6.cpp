#include <stdio.h>

int main(void) {
	int val = 0;
	if (val = 0) {
		printf("A\n");
	} else {
		printf("B\n");
	}

	return 0;
}
