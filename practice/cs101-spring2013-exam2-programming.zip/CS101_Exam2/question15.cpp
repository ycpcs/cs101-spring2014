#include <stdio.h>

// Do not modify this function prototype!
void draw_chars(int count, char ch);

int main(void) {
	// You may change/add code inside the main function.

	return 0;
}

// Do not modify this function!
void draw_chars(int count, char ch) {
	for (int i = 0; i < count; i++) {
		printf("%c", ch);
	}
}

