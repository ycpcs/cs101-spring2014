#include <stdio.h>

#define MAX 20

int main(void) {
	int num_values;      // number of input values
	double values[MAX];  // array to store the input values
	int op;              // which operation to perform

	scanf("%i", &num_values);
	for (int i = 0; i < num_values; i++) {
		scanf("%lf", &values[i]);
	}
	scanf("%i", &op);

	// TODO: add your code here

	return 0;
}
