#include <stdio.h>

// Add a function prototype here.

int main(void) {
	// IMPORTANT: do NOT modify any code in the main function,
	// EXCEPT to uncomment the draw_square(n); line.
	int n;

	printf("Enter an integer: ");
	scanf("%i", &n);

	// You may uncomment the following line.
	//draw_square(n);

	return 0;
}

// Add a function definition here.

