#include <stdio.h>

struct Rectangle {
    float x1,y1;
    float x2,y2;
};

// TODO: add prototype for area function

int main(void) {
	///////////////////////////////////////
	// Important: DO NOT CHANGE the code
	// in the main function except where indicated
	///////////////////////////////////////

    struct Rectangle r;
    float result = 0.0;
    
	// Obtain user input
    printf("Enter x1: ");
	scanf("%f", &r.x1);
	printf("Enter y1: ");
	scanf("%f", &r.y1);
	printf("Enter x2: ");
	scanf("%f", &r.x2);
	printf("Enter y2: ");
	scanf("%f", &r.y2);

    // TODO: Uncomment the following line
	//result = area(&r);

    // Print final output
    printf("Area is %.2f\n",result);
    
	return 0;
}

// TODO: add definition for area function
