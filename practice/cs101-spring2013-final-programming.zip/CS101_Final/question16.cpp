#include <stdio.h>
#include <math.h>

struct Point {
	int x;
	int y;
};

// TODO: add a prototype for the furthestDistance() function

int main(void) {
	struct Point pts[100];
	int n, pt1, pt2;
	double maxDist;
	
	// Load array
	scanf("%i",&n);
	for (int i=0; i < n; i++) {
		scanf("%i %i", &(pts[i].x), &(pts[i].y));
	}
	    
	// Call function
	maxDist = furthestDistance(pts,n,&pt1,&pt2);
	
	printf("Furthest distance %.3lf between ",maxDist);
	printf("(%i, %i) and ", pts[pt1].x, pts[pt1].y);
	printf("(%i, %i)", pts[pt2].x, pts[pt2].y);
	
	return 0;
}

// TODO: add a definition for the furthestDistance() function

