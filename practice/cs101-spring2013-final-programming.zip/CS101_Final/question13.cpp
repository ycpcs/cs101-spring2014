#include <stdio.h>

// TODO: add prototype for isMultiple function

int main(void) {
	///////////////////////////////////////
	// Important: DO NOT CHANGE the code
	// in the main function except where indicated
	///////////////////////////////////////

    int num1, num2;
    int ans;
    
	// Obtain user input
    printf("Enter two integers: ");
	scanf("%i %i", &num1, &num2);

    // TODO: add function call to isMultiple

    // Print final output
    printf("Result is %i\n",ans);
    
	return 0;
}

// TODO: add definition for isMultiple function
