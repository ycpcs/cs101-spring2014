#include <stdio.h>

// TODO: add prototype for the makePurchase function

int main(void) {
	double amount = 100.0;

	// TODO: add code as described in problem description


	printf("Thank you for using YCP National Bank\n");
	return 0;
}

// TODO: add a definition for the makePurchase function
