#include <stdio.h>

#define MAX 10

// TODO: add prototype for arrayExtents function

int main(void) {
	///////////////////////////////////////
	// Important: DO NOT CHANGE the code
	// in the main function
	///////////////////////////////////////

	int vals[MAX];
	int length;
    int count;

	printf("Enter array length: ");
	scanf("%i", &length);

	printf("Enter array values: ");
	for (int i = 0; i < length; i++) {
		scanf("%i", &vals[i]);
	}

	count = arrayExtents(vals, length);

	for (int i = 0; i < length; i++) {
		printf("%i ", vals[i]);
	}
    printf("- %i swaps done\n",count);

	return 0;
}

// TODO: add definition for arrayExtents function
