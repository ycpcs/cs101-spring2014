#include <stdio.h>

#define MAX 10

// TODO: add prototype for arrayExtents function

int main(void) {
	///////////////////////////////////////
	// Important: do NOT change the code
	// in the main function
	///////////////////////////////////////

	int arr[MAX];
	int len;

	printf("Enter array length: ");
	scanf("%i", &len);

	printf("Enter array values: ");
	for (int i = 0; i < len; i++) {
		scanf("%i", &arr[i]);
	}

	arrayExtents(arr, len);

	for (int i = 0; i < len; i++) {
		printf("%i ", arr[i]);
	}
	printf("\n");

	return 0;
}

// TODO: add definition for arrayExtents function
