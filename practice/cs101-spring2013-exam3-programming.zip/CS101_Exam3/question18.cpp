#include <stdio.h>

struct Rect {
	int xmin;
	int ymin;
	int xmax;
	int ymax;
};

struct Point {
	int x;
	int y;
};

// TODO: add prototype for the check_collision function

int main(void) {
	///////////////////////////////////////
	// Important: Do NOT change the code
	// in the main function
	///////////////////////////////////////

	struct Rect r;
	struct Point p;

	printf("Enter the rectangle bounds: ");
	scanf("%i %i %i %i", &r.xmin, &r.xmax, &r.ymin, &r.ymax);

	printf("Enter the point coordinates: ");
	scanf("%i %i", &p.x, &p.y);

	int where = check_collision(r, p);

	printf("Point is ");
	if (where == 0) {
		printf("outside\n");
	} else if (where == 1) {
		printf("inside\n");
	} else if (where == 2) {
		printf("top edge\n");
	} else if (where == 3) {
		printf("bottom edge\n");
	} else if (where == 4) {
		printf("left edge\n");
	} else if (where == 5) {
		printf("right edge\n");
	} else {
		printf("invalid?\n");
	}

	return 0;
}

// TODO: add a definition for the check_collision function

