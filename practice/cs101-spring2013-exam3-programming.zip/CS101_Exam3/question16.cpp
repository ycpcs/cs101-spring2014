#include <stdio.h>

// TODO: add prototype for the scale_xy function


int main(void) {
	////////////////////////////////////////////////////
	// IMPORTANT: do not modify the code
	// in the main function
	////////////////////////////////////////////////////
	double user_x, user_y, scale_factor;

	printf("Enter x/y: ");
	scanf("%lf %lf", &user_x, &user_y);
	printf("Scale factor: ");
	scanf("%lf", &scale_factor);

	scale_xy(&user_x, &user_y, scale_factor);

	printf("x=%lf, y=%lf", user_x, user_y);
	return 0;
}

// TODO: add definition for the scale_xy function
