#include <stdio.h>


struct Point {
	int x, y;
}; 

struct Point init_Point(int xinit, int yinit);


int main(void) {
	///////////////////////////////////////
	// DO NOT modify this section of code
	///////////////////////////////////////
	struct Point p;
	int user_x, user_y;

	printf("Enter x and y values for a Point: ");
	scanf("%i %i", &user_x, &user_y);
	///////////////////////////////////////
	///////////////////////////////////////


	// TODO: Insert your function call to init_Point here


	///////////////////////////////////////
	// DO NOT modify the following line of code
	printf("Point: x=%i, y=%i\n", p.x, p.y);
	///////////////////////////////////////

	return 0;
}


// TODO: Write your init_Point function here
