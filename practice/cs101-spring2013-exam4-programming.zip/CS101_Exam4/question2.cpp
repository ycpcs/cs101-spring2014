#include <stdio.h>

#define MAX 20

struct Transcript {
	int num_classes;
	int credits[MAX];
	double grades[MAX];
};

// TODO: add prototype for the compute_GPA function

int main(void) {
	///////////////////////////////////////////////////////
	// Important: do not modify any code except as
	// indicated by the TODO comments
	///////////////////////////////////////////////////////

	struct Transcript the_transcript;

	printf("How many classes? ");
	scanf("%i", &the_transcript.num_classes);
	for (int i = 0; i < the_transcript.num_classes; i++) {
		printf("Credits: ");
		scanf("%i", &the_transcript.credits[i]);
		printf("Grade: ");
		scanf("%lf", &the_transcript.grades[i]);
	}

	double gpa;
	// TODO: call the compute_GPA function, assign the computed
	// GPA to the gpa variable

	printf("GPA=%lf\n", gpa);

	return 0;
}

// TODO: add definition for the compute_GPA function
