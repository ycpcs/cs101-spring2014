#include <stdio.h>

struct Student {
	int id;
	int num_credits;
	int commuter;
	double amount_due;
};

void init_Student(struct Student *s, int id, int num_credits, int commuter);
void compute_Tuition(struct Student *s, double per_credit);

int main(void) 	{
	//////////////////////////////////////////////////
	// Do not modify the code except as indicated by
	// the TODO comments.
	//////////////////////////////////////////////////

	struct Student the_student;

	int id_input, num_credits_input, commuter_input;
	double per_credit_input;

	printf("ID: ");
	scanf("%i", &id_input);
	printf("Number of credits: ");
	scanf("%i", &num_credits_input);
	printf("Commuter (1=yes, 0=no): ");
	scanf("%i", &commuter_input);
	printf("Amount per credit: ");
	scanf("%lf", &per_credit_input);

	// TODO: write a call to the init_Student function to initialize
	// the struct Student variable called the_student

	printf("id=%i\nnum_credits=%i\ncommuter=%i\n",
		the_student.id,
		the_student.num_credits,
		the_student.commuter);

	// TODO: write a call to the compute_Tuition function to compute
	// the tuition for the_student, storing the result in
	// the amount_due field

	printf("amount_due=%.2lf\n", the_student.amount_due);

	return 0;
}

void init_Student(struct Student *s, int id, int num_credits, int commuter) {
	printf("Initialization function called\n");
	s->id = id;
	s->num_credits = num_credits;
	s->commuter = commuter;
	s->amount_due = 0.0;
}

void compute_Tuition(struct Student *s, double per_credit) {
	printf("Compute tuition function called\n");
	s->amount_due = s->num_credits * per_credit;
}
