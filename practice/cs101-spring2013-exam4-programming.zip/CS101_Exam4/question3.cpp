#include <stdio.h>

#define MAX 20

// Do not change the prototype of this function
int find_occurrences(int arr[], int length, int val, int occur[]);

int main(void) {
	////////////////////////////////////////////////
	// Important: don't change any code in main
	////////////////////////////////////////////////

	int input_arr[MAX];
	int myoccur[MAX];
	int mylength;

	printf("How many values? ");
	scanf("%i", &mylength);
	printf("Enter values: ");
	for (int i = 0; i < mylength; i++) {
		scanf("%i", &input_arr[i]);
	}
	printf("Search for? ");
	int myval;
	scanf("%i", &myval);

	int noccur = find_occurrences(input_arr, mylength, myval, myoccur);

	printf("Found %i occurrence(s): ", noccur);
	for (int i = 0; i < noccur; i++) {
		printf("%i ", myoccur[i]);
	}
	printf("\n");
	return 0;
}

int find_occurrences(int arr[], int length, int val, int occur[]) {
	// TODO: add code

}
