#include <stdio.h>
#include <math.h>
#include <stdbool.h>

struct Point {
	double x;
	double y;
};

struct Circle {
	struct Point c;
	double r;
};

void initCircle(struct Circle *cir, double x, double y, double r);
// TODO: add a prototype for the overlap(function

int main(void) {
	////////////////////////////////////////////////////////
	// Important: do not change any of the code in
	// the main function
	////////////////////////////////////////////////////////

	struct Circle c1, c2;
	double x, y, r;
	double dist,sum;
	bool result;
	
	// Load circles
	printf("x1/y1/r1: ");
	scanf("%lf %lf %lf", &x, &y, &r);
	printf("x2/y2/r2: ");
	initCircle(&c1,x,y,r);
	scanf("%lf %lf %lf", &x, &y, &r);
	initCircle(&c2,x,y,r);
	    
	// Call function
	result = overlap(c1,c2,&dist,&sum);
	
	printf("%.3lf %.3lf ",dist,sum);
	if (result) {
	    printf("overlap\n");
	} else {
	    printf("non-overlap\n");
	}
	
	return 0;
}

// TODO: add a definition for the overlap function


// Circle initialization function
void initCircle(struct Circle *cir, double x, double y, double r) {
	cir->c.x = x;
	cir->c.y = y;
	cir->r = r;
}
