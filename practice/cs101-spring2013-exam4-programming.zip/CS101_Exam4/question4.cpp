#include <stdio.h>

#define MAX 20

struct Point {
	int x, y;
};

struct Rect {
	struct Point minxy;
	int width;
	int height;
};

// Do not modify this function prototype
int count_inside(struct Point *p, struct Rect rectlist[], int nrects);

int main(void) {
	/////////////////////////////////////////////////////////
	// Important: do not modify the code in the main function
	/////////////////////////////////////////////////////////

	struct Point the_point;
	int the_nrects;
	struct Rect the_rectlist[MAX];

	printf("Point x/y: ");
	scanf("%i %i", &the_point.x, &the_point.y);

	printf("Number of rects: ");
	scanf("%i", &the_nrects);

	for (int i = 0; i < the_nrects; i++) {
		printf("Min x/y: ");
		struct Point the_minxy;
		scanf("%i %i", &the_minxy.x, &the_minxy.y);
		the_rectlist[i].minxy = the_minxy;
		printf("Width/height: ");
		scanf("%i %i", &the_rectlist[i].width, &the_rectlist[i].height);
	}

	int num_inside;
	num_inside = count_inside(&the_point, the_rectlist, the_nrects);

	printf("Point is inside %i rectangles\n", num_inside);

	return 0;
}

int count_inside(struct Point *p, struct Rect rectlist[], int nrects) {
	// TODO: add code

}
